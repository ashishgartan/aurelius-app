// context/SettingsContext.tsx
"use client"

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
  useCallback,
  type ReactNode,
} from "react"
import type { UserSettings } from "@/types/auth"
import { DEFAULT_SETTINGS } from "@/types/auth"
import { saveSettingsRequest } from "@/lib/settings/saveSettings"

interface SettingsContextValue {
  settings: UserSettings
  loading: boolean
  saving: boolean
  save: (patch: Partial<UserSettings>) => Promise<void>
  reset: () => Promise<void>
}

const SettingsContext = createContext<SettingsContextValue | null>(null)

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<UserSettings>(DEFAULT_SETTINGS)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const settingsRef = useRef(settings)
  useEffect(() => { settingsRef.current = settings }, [settings])

  useEffect(() => {
    fetch("/api/settings", { credentials: "include" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.settings) setSettings(d.settings)
      })
      .catch((err) => console.warn("[SettingsContext] fetch initial settings failed:", err))
      .finally(() => setLoading(false))
  }, [])

  const save = useCallback(
    async (patch: Partial<UserSettings>) => {
      setSaving(true)
      const generalPatch = { ...patch }
      delete generalPatch.smtpUser
      delete generalPatch.smtpPass
      const smtpOnly = Object.keys(generalPatch).length === 0
      const requestPatch = smtpOnly ? patch : generalPatch
      const merged = smtpOnly
        ? { ...settingsRef.current, ...patch }
        : {
            ...settingsRef.current,
            ...generalPatch,
            smtpUser: settingsRef.current.smtpUser,
            smtpPass: settingsRef.current.smtpPass,
          }
      const prev   = settingsRef.current

      setSettings(merged) // optimistic update

      try {
        const saved = await saveSettingsRequest(fetch, merged, requestPatch)
        setSettings(saved)
      } catch (err) {
        console.error("[SettingsContext] save failed:", err)
        setSettings(prev) // rollback
        throw err
      } finally {
        setSaving(false)
      }
    },
    []
  )

  const reset = useCallback(async () => {
    await save(DEFAULT_SETTINGS)
  }, [save])

  return (
    <SettingsContext.Provider
      value={{ settings, loading, saving, save, reset }}
    >
      {children}
    </SettingsContext.Provider>
  )
}

export function useSettings(): SettingsContextValue {
  const ctx = useContext(SettingsContext)
  if (!ctx)
    throw new Error("useSettings must be used inside <SettingsProvider>")
  return ctx
}
