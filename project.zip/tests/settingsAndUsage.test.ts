import test from "node:test"
import assert from "node:assert/strict"
import { DEFAULT_SETTINGS } from "../types/auth.ts"
import { saveSettingsRequest } from "../lib/settings/saveSettings.ts"
import { estimateCost } from "../lib/services/usageCost.ts"

test("saveSettingsRequest returns saved settings from the API response", async () => {
  const saved = await saveSettingsRequest(
    async () =>
      new Response(
        JSON.stringify({
          settings: {
            ...DEFAULT_SETTINGS,
            tone: "technical",
          },
        }),
        { status: 200 }
      ),
    DEFAULT_SETTINGS,
    { tone: "casual" }
  )

  assert.equal(saved.tone, "technical")
})

test("saveSettingsRequest throws the server error on failed saves", async () => {
  await assert.rejects(
    () =>
      saveSettingsRequest(
        async () =>
          new Response(JSON.stringify({ error: "Forbidden" }), { status: 403 }),
        DEFAULT_SETTINGS,
        { tone: "casual" }
      ),
    /Forbidden/
  )
})

test("estimateCost reports zero cost for local qwen usage", () => {
  assert.equal(estimateCost("qwen", 100000, 100000), 0)
})
