import test from "node:test"
import assert from "node:assert/strict"
import { checkCsrf } from "../lib/csrf.ts"

test("checkCsrf allows localhost on any dev port", () => {
  const env = process.env as Record<string, string | undefined>
  const originalNodeEnv = env.NODE_ENV
  const originalNextauthUrl = env.NEXTAUTH_URL
  const originalAppUrl = env.APP_URL

  try {
    env.NODE_ENV = "development"
    env.NEXTAUTH_URL = ""
    env.APP_URL = ""

    const req = new Request("http://localhost:4321/api/settings", {
      method: "PUT",
      headers: { origin: "http://localhost:4321" },
    })

    assert.equal(checkCsrf(req), null)
  } finally {
    env.NODE_ENV = originalNodeEnv
    env.NEXTAUTH_URL = originalNextauthUrl
    env.APP_URL = originalAppUrl
  }
})
