// hooks/useChat.ts
"use client"

import { useState, useRef, useCallback, useEffect } from "react"
import type { ChatMessage, Provider, ToolCall, UserSettings, ArtifactRef } from "@/types/chat"
import type { AgentChunk } from "@/lib/agent"

interface UseChatOptions {
  sessionId:       string
  initialMessages: ChatMessage[]
  provider:        Provider
  settings?:  Pick<UserSettings, "instructions" | "language" | "length" | "tone" | "enabledTools">
  onNewTitle?:     (title: string) => void
  onBump?:         () => void
}

// Three explicit states for history initialisation:
//   "idle"    — waiting for initialMessages to arrive from the API
//   "loaded"  — history arrived and has been written to `messages`
//   "active"  — user has sent at least one message; history is locked in
type InitState = "idle" | "loaded" | "active"

function escapeForRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
}

export function useChat({
  sessionId, initialMessages, provider, settings, onNewTitle, onBump,
}: UseChatOptions) {
  const [messages,  setMessages]  = useState<ChatMessage[]>(initialMessages)
  const [streaming, setStreaming] = useState(false)
  const abortRef    = useRef<AbortController | null>(null)
  const initRef     = useRef<InitState>("idle")

  // Always reflects the latest provider prop without re-creating callbacks.
  const providerRef  = useRef<Provider>(provider)
  const settingsRef  = useRef(settings)
  useEffect(() => { providerRef.current = provider }, [provider])
  useEffect(() => { settingsRef.current = settings }, [settings])

  // Sync history from API → local state.
  useEffect(() => {
    if (initRef.current === "idle") {
      setMessages(initialMessages)
      if (initialMessages.length > 0) initRef.current = "loaded"
    }
  }, [initialMessages])

  // Reset everything when the user navigates to a different chat.
  useEffect(() => {
    initRef.current = "idle"
    setMessages([])
    setStreaming(false)
  }, [sessionId])

  // ── Core stream function ──────────────────────────────────────────
  // Sends the current message to /api/chat and streams the response.
  // History is NOT sent — the backend loads it from DB on every request.
  // saveUser tells the backend whether to persist the user message
  // (false for regenerate, where the user message is already in DB).
  const streamAssistant = useCallback(async (
    userText:       string,
    asstId:         string,
    activeProvider: Provider,
    saveUser        = true
  ): Promise<boolean> => {
    const abort = new AbortController()
    abortRef.current = abort

    try {
      const res = await fetch("/api/chat", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({
          message:  userText,
          provider: activeProvider,
          sessionId,
          saveUser,
          ...settingsRef.current,
        }),
        signal: abort.signal,
      })

      if (!res.ok) {
        const { error } = await res.json().catch(() => ({ error: `Error ${res.status}` }))
        setMessages((prev) =>
          prev.map((m) => m._id === asstId ? { ...m, content: error } : m)
        )
        return false
      }

      const reader  = res.body!.getReader()
      const decoder = new TextDecoder()

      // toolCalls is built up during streaming for UI only — the DB stores only text.
      let thinkingContent = ""
      let lineBuf         = ""
      const toolCalls: ToolCall[] = []

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        lineBuf += decoder.decode(value, { stream: true })

        // Split on newlines to find event: lines vs plain text
        const parts = lineBuf.split("\n")
        // The last part may be an incomplete line — keep it buffered
        lineBuf = parts.pop() ?? ""

        for (const part of parts) {
          if (part.startsWith("event:")) {
            try {
              const chunk = JSON.parse(part.slice(6)) as AgentChunk

              if (chunk.type === "tool_start") {
                toolCalls.push({ tool: chunk.tool, input: chunk.input })
                setMessages((prev) =>
                  prev.map((m) => m._id === asstId ? { ...m, toolCalls: [...toolCalls] } : m)
                )
              } else if (chunk.type === "tool_end") {
                const tc = [...toolCalls].reverse()
                  .find((t) => t.tool === chunk.tool && t.output === undefined)
                if (tc) tc.output = chunk.output
                setMessages((prev) =>
                  prev.map((m) => m._id === asstId ? { ...m, toolCalls: [...toolCalls] } : m)
                )
              } else if (chunk.type === "thinking_token") {
                thinkingContent += chunk.content
                const snap = thinkingContent
                setMessages((prev) =>
                  prev.map((m) => m._id === asstId ? { ...m, thinking: snap } : m)
                )
              } else if (chunk.type === "title") {
                // Backend generated a title after the first exchange — update the sidebar
                onNewTitle?.(chunk.title)
              } else if (chunk.type === "artifact") {
                // A code block was uploaded to Cloudinary.
                // Strip the raw code fence from the streamed content — the client
                // received it as text tokens during streaming, but now we replace
                // it with a clean file card. We match ```lang\n...\n``` greedily
                // so multi-block responses each get their own card.
                const ref: ArtifactRef = {
                  artifactId: chunk.artifactId,
                  filename:   chunk.filename,
                  lang:       chunk.lang,
                  sizeBytes:  chunk.sizeBytes,
                }
                setMessages((prev) =>
                  prev.map((m) => {
                    if (m._id !== asstId) return m
                    // Remove the first matching code fence for this lang from content
                    const fencePattern = new RegExp(
                      "```" +
                        (chunk.lang
                          ? escapeForRegExp(chunk.lang)
                          : "[\\w+#.-]*") +
                        "\\n[\\s\\S]*?\\n```",
                      ""
                    )
                    const stripped = (m.content ?? "").replace(fencePattern, "").trim()
                    return {
                      ...m,
                      content:   stripped,
                      artifacts: [...(m.artifacts ?? []), ref],
                    }
                  })
                )
              }
            } catch { /* malformed event line — skip */ }
          } else {
            // Always include this line, even if empty.
            // Empty lines are meaningful in markdown — they separate headings,
            // paragraphs, and list endings. Skipping them merges content together.
            setMessages((prev) =>
              prev.map((m) =>
                m._id === asstId ? { ...m, content: (m.content ?? "") + part + "\n" } : m
              )
            )
          }
        }
      }

      // Flush any remaining buffered content that didn't end with \n.
      // This can be a plain text fragment OR a final event: line that arrived
      // without a trailing newline — handle both cases.
      if (lineBuf) {
        if (lineBuf.startsWith("event:")) {
          // Parse it exactly like the lines in the main loop above
          try {
            const chunk = JSON.parse(lineBuf.slice(6)) as AgentChunk
            if (chunk.type === "title") {
              onNewTitle?.(chunk.title)
            } else if (chunk.type === "artifact") {
              const ref: ArtifactRef = {
                artifactId: chunk.artifactId,
                filename:   chunk.filename,
                lang:       chunk.lang,
                sizeBytes:  chunk.sizeBytes,
              }
              const fencePattern = new RegExp(
                "```" +
                  (chunk.lang ? escapeForRegExp(chunk.lang) : "[\\w+#.-]*") +
                  "\\n[\\s\\S]*?\\n```",
                ""
              )
              setMessages((prev) =>
                prev.map((m) => {
                  if (m._id !== asstId) return m
                  const stripped = (m.content ?? "").replace(fencePattern, "").trim()
                  return { ...m, content: stripped, artifacts: [...(m.artifacts ?? []), ref] }
                })
              )
            }
          } catch { /* malformed — ignore */ }
        } else {
          setMessages((prev) =>
            prev.map((m) =>
              m._id === asstId ? { ...m, content: (m.content ?? "") + lineBuf } : m
            )
          )
        }
      }

      // Trim the trailing newline that the line-splitting loop adds to the
      // last text chunk. Every line from split("\n") has "\n" re-appended
      // so it round-trips correctly through markdown, but the very last line
      // ends up with a spurious trailing newline once streaming is complete.
      setMessages((prev) =>
        prev.map((m) =>
          m._id === asstId
            ? { ...m, content: (m.content ?? "").replace(/\n$/, "") }
            : m
        )
      )

      onBump?.()
      return true
    } catch (err: unknown) {
      if ((err as { name?: string }).name === "AbortError") return false
      console.error("[useChat] stream error:", err)
      setMessages((prev) =>
        prev.map((m) =>
          m._id === asstId
            ? { ...m, content: "Something went wrong. Please try again." }
            : m
        )
      )
      return false
    } finally {
      setStreaming(false)
      abortRef.current = null
    }
  }, [sessionId, onBump, onNewTitle])

  // ── Send a new message ────────────────────────────────────────────
  const send = useCallback(async (text: string) => {
    if (!text.trim() || streaming) return

    const activeProvider = providerRef.current
    initRef.current = "active"

    const userMsg: ChatMessage = {
      _id: crypto.randomUUID(), role: "user", content: text,
      model: activeProvider, createdAt: new Date().toISOString(),
    }
    const asstMsg: ChatMessage = {
      _id: crypto.randomUUID(), role: "assistant", content: "",
      model: activeProvider, createdAt: new Date().toISOString(),
    }

    setMessages((prev) => [...prev, userMsg, asstMsg])
    setStreaming(true)

    // saveUser=true (default): backend will persist user then assistant in correct order.
    await streamAssistant(text, asstMsg._id, activeProvider)
  }, [streaming, streamAssistant])

  // ── Regenerate ────────────────────────────────────────────────────
  const regenerate = useCallback(async () => {
    if (streaming) return

    const activeProvider = providerRef.current
    const lastUserIdx = [...messages].reverse().findIndex((m) => m.role === "user")
    if (lastUserIdx === -1) return
    const lastUser = [...messages].reverse()[lastUserIdx]

    const lastUserAbsIdx = messages.length - 1 - lastUserIdx

    const newAsstId  = crypto.randomUUID()
    const newAsstMsg: ChatMessage = {
      _id:       newAsstId,
      role:      "assistant",
      content:   "",
      model:     activeProvider,
      createdAt: new Date().toISOString(),
    }

    setMessages((prev) => [...prev.slice(0, lastUserAbsIdx + 1), newAsstMsg])
    setStreaming(true)

    // Truncate DB to remove the old assistant response so the backend loads
    // the correct history (ending with the user message, not the stale reply).
    try {
      const res = await fetch(
        `/api/sessions/${sessionId}/messages?fromIndex=${lastUserAbsIdx + 1}`,
        { method: "DELETE" }
      )

      if (!res.ok) {
        const { error } = await res.json().catch(() => ({ error: `Error ${res.status}` }))
        throw new Error(error)
      }
    } catch (err) {
      console.error("[useChat] regenerate truncate failed:", err)
      setMessages(messages)
      setStreaming(false)
      return
    }

    // saveUser=false: the user message is already in DB after the truncation above.
    await streamAssistant(lastUser.content, newAsstId, activeProvider, false)
  }, [messages, streaming, sessionId, streamAssistant])


  // ── Edit a past message + resend from that point ─────────────────
  // Replaces the message at `messageId` with `newText`, removes all
  // subsequent messages, then streams a fresh assistant response.
  const editAndResend = useCallback(async (messageId: string, newText: string) => {
    if (!newText.trim() || streaming) return

    const activeProvider = providerRef.current

    const editIdx = messages.findIndex((m) => m._id === messageId)
    if (editIdx === -1) return

    const editedMsg: ChatMessage = { ...messages[editIdx], content: newText }
    const asstMsg: ChatMessage = {
      _id:       crypto.randomUUID(),
      role:      "assistant",
      content:   "",
      model:     activeProvider,
      createdAt: new Date().toISOString(),
    }

    setMessages([...messages.slice(0, editIdx), editedMsg, asstMsg])
    setStreaming(true)
    initRef.current = "active"

    // Truncate DB from editIdx onwards — the backend will save the edited user
    // message and the new assistant reply in the correct order.
    try {
      const res = await fetch(`/api/sessions/${sessionId}/messages?fromIndex=${editIdx}`, {
        method: "DELETE",
      })

      if (!res.ok) {
        const { error } = await res.json().catch(() => ({ error: `Error ${res.status}` }))
        throw new Error(error)
      }
    } catch (err) {
      console.error("[useChat] edit truncate failed:", err)
      setMessages(messages)
      setStreaming(false)
      return
    }

    // saveUser=true: backend saves the edited user message before streaming.
    await streamAssistant(newText, asstMsg._id, activeProvider, true)
  }, [messages, streaming, sessionId, streamAssistant])

  const stop = useCallback(() => {
    abortRef.current?.abort()
    setStreaming(false)
  }, [])

  const clearLocal = useCallback(() => {
    setMessages([])
    initRef.current = "idle"
  }, [])

  return { messages, streaming, send, regenerate, editAndResend, stop, clearLocal }
}
