// app/chat/[chatId]/page.tsx
"use client"

import { use, useEffect, useState, useCallback, useRef, startTransition } from "react"
import { useRouter } from "next/navigation"
import { useChat } from "@/hooks/useChat"
import { useChatStore } from "@/hooks/useChatStore"
import { useArtifactStore } from "@/hooks/useArtifactStore"
import { ChatHeader } from "@/components/chat/ChatHeader"
import { MessageList } from "@/components/chat/MessageList"
import { ChatInput } from "@/components/chat/ChatInput"
import { ArtifactPanel } from "@/components/chat/ArtifactPanel"
import { useSidebarOpener } from "@/context/SidebarContext"
import { useMessageSearch } from "@/hooks/useMessageSearch"
import { useSettings } from "@/context/SettingsContext"
import { Bot } from "lucide-react"
import { ErrorBoundary } from "@/components/ErrorBoundary"
import { MessageSkeleton } from "@/components/chat/MessageSkeleton"
import type { ChatMessage, Provider } from "@/types/chat"
import type { UploadedDoc } from "@/components/chat/FileUpload"
import { ToolAvailabilityInfo } from "@/components/chat/ToolAvailabilityInfo"
import {
  buildChatDraftKey,
  clearChatDraft,
  readChatDraft,
  writeChatDraft,
} from "@/lib/chat/drafts"
import {
  buildDocumentSummaryPrompt,
  clearChatOnServer,
} from "@/lib/chat/pageActions"

interface PageProps {
  params: Promise<{ chatId: string }>
}

export default function ChatPage({ params }: PageProps) {
  const { chatId } = use(params)
  const draftKey = buildChatDraftKey(chatId)
  const router = useRouter()
  const openSidebar = useSidebarOpener()

  const { bumpSession, renameSession, updateProvider } = useChatStore()
  const { settings } = useSettings()

  const [initialMessages, setInitialMessages] = useState<ChatMessage[]>([])
  const [provider, setProvider] = useState<Provider>("groq")
  const [title, setTitle] = useState("")
  const [input, setInput] = useState("")
  const [docs, setDocs] = useState<UploadedDoc[]>([])
  const [pageLoading, setPageLoading] = useState(true)
  const [notFound, setNotFound] = useState(false)
  const [clearState, setClearState] = useState<"idle" | "clearing" | "error">(
    "idle"
  )
  const [artifactWidth, setArtifactWidth] = useState(480)
  const [artifactExpanded, setArtifactExpanded] = useState(false)
  const [isDraggingArtifact, setIsDraggingArtifact] = useState(false)
  const artifactStartX = useRef(0)
  const artifactStartWidth = useRef(480)
  const { isOpen: isArtifactOpen } = useArtifactStore()

  useEffect(() => {
    startTransition(() => {
      setPageLoading(true)
      setNotFound(false)
      setInitialMessages([])
      setTitle("")
      setClearState("idle")
    })
    try {
      const draft = readChatDraft(localStorage, chatId)
      startTransition(() => {
        setInput(draft)
      })
    } catch {
      startTransition(() => {
        setInput("")
      })
    }

    fetch(`/api/sessions/${chatId}`)
      .then(async (res) => {
        if (!res.ok) {
          setNotFound(true)
          return
        }
        const { session } = await res.json()
        setInitialMessages(session.messages ?? [])
        setProvider(session.provider ?? "groq")
        setTitle(session.title ?? "")
        // Load existing documents for this session
        fetch(`/api/sessions/${chatId}/documents`)
          .then((r) => (r.ok ? r.json() : null))
          .then((d) => {
            if (d?.documents) setDocs(d.documents)
          })
          .catch(console.error)
      })
      .catch(() => setNotFound(true))
      .finally(() => setPageLoading(false))
  }, [chatId, draftKey])

  useEffect(() => {
    try {
      writeChatDraft(localStorage, chatId, input)
    } catch {
      // Ignore storage errors in private mode / restricted contexts.
    }
  }, [chatId, input])

  const handleNewTitle = useCallback(
    (t: string) => {
      setTitle(t)
      void renameSession(chatId, t).catch((err) => {
        console.error("[chat/page] renameSession failed:", err)
      })
    },
    [chatId, renameSession]
  )

  const handleBump = useCallback(
    () => bumpSession(chatId),
    [chatId, bumpSession]
  )

  const {
    messages,
    streaming,
    send,
    regenerate,
    editAndResend,
    stop,
    clearLocal,
  } = useChat({
    sessionId: chatId,
    initialMessages,
    provider,
    settings,
    onNewTitle: handleNewTitle,
    onBump: handleBump,
  })

  // Listen for Escape key stop-stream event dispatched by useKeyboardShortcuts
  useEffect(() => {
    const handler = () => {
      if (streaming) stop()
    }
    window.addEventListener("aurelius:stop-stream", handler)
    return () => window.removeEventListener("aurelius:stop-stream", handler)
  }, [streaming, stop])

  // Cmd+F → open in-chat search
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "f") {
        e.preventDefault()
        window.dispatchEvent(new CustomEvent("aurelius:open-search"))
      }
    }
    window.addEventListener("keydown", handler)
    return () => window.removeEventListener("keydown", handler)
  }, [])

  const {
    searchQuery,
    onSearchChange,
    matchCount,
    matchIndex,
    onMatchNav,
    matches,
    activeMessageId,
  } = useMessageSearch(messages)

  const handleDocUploaded = (doc: UploadedDoc) => {
    setDocs((prev) => [...prev, doc])
  }

  const handleDocRemove = async (docId: string) => {
    const res = await fetch(`/api/sessions/${chatId}/documents/${docId}`, {
      method: "DELETE",
    })
    if (!res.ok) {
      console.error("[handleDocRemove] failed:", await res.text().catch(() => "unknown error"))
      return
    }
    setDocs((prev) => prev.filter((d) => d._id !== docId))
  }

  const handleDocSummarize = (doc: UploadedDoc) => {
    const prompt = buildDocumentSummaryPrompt(doc)
    setInput("")
    send(prompt)
  }

  const handleSend = () => {
    if (!input.trim()) return
    send(input.trim())
    setInput("")
    try {
      clearChatDraft(localStorage, chatId)
    } catch {
      // ignore storage errors
    }
  }

  const handleSuggestion = useCallback(
    (prompt: string) => {
      setInput(prompt)
      // Defer send by one tick so the input state has updated before we read it
      setTimeout(() => {
        send(prompt)
        setInput("")
      }, 0)
    },
    [send]
  )

  const handleProviderChange = (p: Provider) => {
    const previous = provider
    setProvider(p)
    void updateProvider(chatId, p).catch((err) => {
      console.error("[chat/page] updateProvider failed:", err)
      setProvider(previous)
    })
  }

  // Server-first clear: persist to DB first, update UI only on success.
  // On failure: leave messages intact, show a retry-able error state.
  const handleClear = useCallback(async () => {
    if (clearState === "clearing") return
    setClearState("clearing")

    try {
      await clearChatOnServer(fetch, chatId)

      // Server confirmed — now safe to clear local state
      clearLocal()
      setTitle("New chat")
      await renameSession(chatId, "New chat")
      setInput("")
      try {
        clearChatDraft(localStorage, chatId)
      } catch {
        // ignore storage errors
      }
      setClearState("idle")
    } catch (err) {
      console.error("[handleClear] failed:", err)
      // Messages are untouched — user can retry via the error button
      setClearState("error")
      // Auto-reset error indicator after 4 s so it doesn't linger forever
      setTimeout(() => setClearState("idle"), 4_000)
    }
    }, [chatId, clearState, clearLocal, renameSession])

  const handleToggleArtifactWidth = useCallback(() => {
    setArtifactExpanded((prev) => {
      const next = !prev
      const nextWidth = next ? 740 : 480
      setArtifactWidth(nextWidth)
      return next
    })
  }, [])

  const handleArtifactDragStart = (event: React.MouseEvent<HTMLDivElement>) => {
    event.preventDefault()
    artifactStartX.current = event.clientX
    artifactStartWidth.current = artifactWidth
    setIsDraggingArtifact(true)
  }

  useEffect(() => {
    if (!isDraggingArtifact) return
    const handleMouseMove = (event: MouseEvent) => {
      const delta = artifactStartX.current - event.clientX
      let nextWidth = artifactStartWidth.current + delta
      nextWidth = Math.max(320, Math.min(820, nextWidth))
      setArtifactWidth(nextWidth)
      setArtifactExpanded(nextWidth >= 640)
    }

    const handleMouseUp = () => setIsDraggingArtifact(false)

    document.addEventListener("mousemove", handleMouseMove)
    document.addEventListener("mouseup", handleMouseUp)

    return () => {
      document.removeEventListener("mousemove", handleMouseMove)
      document.removeEventListener("mouseup", handleMouseUp)
    }
  }, [isDraggingArtifact])

  if (pageLoading) {
    return (
      <div className="flex h-full min-h-0 flex-1 flex-col overflow-hidden">
        <ChatHeader
          title={title}
          sessionId={chatId}
          messages={[]}
          showClear={false}
          clearState="idle"
          onClear={() => {}}
          onMenuOpen={openSidebar}
          searchQuery=""
          onSearchChange={() => {}}
          matchIndex={0}
          matchCount={0}
          onMatchNav={() => {}}
        />
        <div className="relative flex flex-1 flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto">
            <MessageSkeleton />
          </div>
        </div>
        <ChatInput
          value=""
          onChange={() => {}}
          onSend={() => {}}
          onStop={() => {}}
          streaming={false}
          provider="groq"
          onProvider={() => {}}
          disabled
        />
      </div>
    )
  }

  if (notFound) {
    return (
      <>
        <ChatHeader
          title="Not found"
          sessionId={chatId}
          messages={[]}
          showClear={false}
          clearState="idle"
          onClear={() => {}}
          onMenuOpen={openSidebar}
          searchQuery=""
          onSearchChange={() => {}}
          matchCount={0}
          matchIndex={0}
          onMatchNav={() => {}}
        />
        <div className="flex flex-1 flex-col items-center justify-center gap-3 text-muted-foreground/40">
          <Bot className="size-8" />
          <p className="text-sm">Chat not found</p>
          <button
            onClick={() => router.push("/chat")}
            className="text-xs underline underline-offset-2 transition-colors hover:text-muted-foreground"
          >
            Go back
          </button>
        </div>
      </>
    )
  }

  return (
    <div className="flex h-full min-h-0 flex-1 flex-row overflow-hidden bg-transparent">
      {/* Main Chat Area */}
      <div className="flex h-full min-h-0 flex-1 flex-col overflow-hidden transition-all duration-300">
        <div className="shrink-0">
          <ChatHeader
            title={title}
            sessionId={chatId}
            messages={messages}
            showClear={messages.length > 0}
            clearState={clearState}
            onClear={handleClear}
            onMenuOpen={openSidebar}
            searchQuery={searchQuery}
            onSearchChange={onSearchChange}
            matchCount={matchCount}
            matchIndex={matchIndex}
            onMatchNav={onMatchNav}
          />
          <ToolAvailabilityInfo />
        </div>
        <ErrorBoundary
          fallback={
            <div className="flex flex-1 flex-col items-center justify-center gap-3 text-muted-foreground/40">
              <Bot className="size-8" />
              <p className="text-sm">Failed to render messages</p>
              <button
                onClick={() => window.location.reload()}
                className="text-xs underline underline-offset-2 transition-colors hover:text-muted-foreground"
              >
                Reload
              </button>
            </div>
          }
        >
          <MessageList
            messages={messages}
            streaming={streaming}
            onRegenerate={regenerate}
            onEditMessage={editAndResend}
            onSuggestion={handleSuggestion}
            searchMatches={matches}
            activeMessageId={activeMessageId}
          />
        </ErrorBoundary>
        <ChatInput
          value={input}
          onChange={setInput}
          onSend={handleSend}
          onStop={stop}
          streaming={streaming}
          provider={provider}
          onProvider={handleProviderChange}
          sessionId={chatId}
          docs={docs}
          onDocUploaded={handleDocUploaded}
          onDocRemove={handleDocRemove}
          onDocSummarize={handleDocSummarize}
        />
      </div>

      {isArtifactOpen && (
        <div
          className="relative h-full w-2 cursor-col-resize bg-border/0 transition-colors hover:bg-border/60"
          onMouseDown={handleArtifactDragStart}
        >
          <div className="absolute inset-y-1/3 left-1/2 h-1/3 w-px -translate-x-1/2 bg-border/60" />
        </div>
      )}

      {/* Side Panel for Runnable Code Artifacts */}
      <ArtifactPanel
        width={artifactWidth}
        isExpanded={artifactExpanded}
        onToggleExpand={handleToggleArtifactWidth}
      />
    </div>
  )
}
