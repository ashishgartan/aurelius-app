// app/(chat)/tools/page.tsx
"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Check, Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"
import { useSettings } from "@/context/SettingsContext"
import { useToolCatalog } from "@/hooks/useToolCatalog"
import type { ToolId } from "@/types/auth"

export default function ToolsPage() {
  const router = useRouter()
  const { settings, save } = useSettings()
  const { catalog, byId } = useToolCatalog()

  const [smtpForm, setSmtpForm] = useState({
    user: settings.smtpUser ?? "",
    pass: settings.smtpPass ?? "",
  })
  const [smtpSaving, setSmtpSaving] = useState(false)
  const [smtpMessage, setSmtpMessage] = useState("")

  const smtpConfigured = Boolean(
    (settings.smtpUser || smtpForm.user) &&
      (settings.smtpPass || smtpForm.pass)
  )

  useEffect(() => {
    setSmtpForm({
      user: settings.smtpUser ?? "",
      pass: settings.smtpPass ?? "",
    })
  }, [
    settings.smtpUser,
    settings.smtpPass,
  ])

  // Optimistic override — non-null only while a save is in flight
  const [optimistic, setOptimistic] = useState<string[] | null>(null)
  const [savingTool, setSavingTool] = useState<ToolId | null>(null)
  const [lastSaved, setLastSaved] = useState<ToolId | null>(null)
  const [error, setError] = useState("")

  // Source of truth is settings.enabledTools from context.
  // During a save we show the optimistic value so the UI feels instant.
  const enabledTools = optimistic ?? settings.enabledTools ?? []
  const enabledCount = enabledTools.length
  const setupGuidance = catalog.filter((tool) => !tool.available && tool.envVar)

  const toggleTool = async (id: ToolId) => {
    if (id === "productivity_agent" && !smtpConfigured && !enabledTools.includes(id)) {
      setError("Enter SMTP credentials before enabling the email tool.")
      return
    }
    if (!byId[id]?.available) return

    const next = enabledTools.includes(id)
      ? enabledTools.filter((t) => t !== id)
      : [...enabledTools, id]

    setOptimistic(next) // instant UI feedback
    setSavingTool(id)
    setError("")

    // Only pass the field that changed — let SettingsContext merge on top
    // of the latest state. Spreading `settings` here caused stale overwrites.
    try {
      await save({ enabledTools: next })
      setOptimistic(null) // hand back to context (now has the saved value)
      setSavingTool(null)
      setLastSaved(id)
      setTimeout(() => setLastSaved(null), 1500)
    } catch (err) {
      setOptimistic(null)
      setSavingTool(null)
      setError(err instanceof Error ? err.message : "Failed to save tool settings")
    }
  }

  return (
    <div className="min-h-0 flex-1 overflow-y-auto">
      <div className="mx-auto flex w-full max-w-xl flex-col gap-6 px-4 py-8">
        {/* Back */}
        <button
          onClick={() => router.back()}
          className="flex w-fit items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-3.5" />
          Back
        </button>

      <div>
        <h1 className="text-xl font-semibold text-foreground">
          Tools
          {enabledCount > 0 && (
            <span className="ml-2 rounded-full bg-primary/10 px-2 py-0.5 text-sm font-medium text-primary">
              {enabledCount} active
            </span>
          )}
        </h1>
        <p className="mt-0.5 text-xs text-muted-foreground">
          Toggle tools on or off — changes save automatically
        </p>
      </div>

      {setupGuidance.length > 0 && (
        <div className="rounded-xl border border-border bg-destructive/10 px-4 py-3 text-[11px] text-destructive">
          {setupGuidance.map((tool) => (
            <p key={tool.id}>
              {tool.label} requires <code>{tool.envVar}</code> to be set on the server
              before it can be enabled ({tool.note}).
            </p>
          ))}
        </div>
      )}

      {/* Info banner */}
          <div className="rounded-xl border border-border bg-muted/30 px-4 py-3">
        <p className="text-[11px] leading-relaxed text-muted-foreground">
          All tools are{" "}
          <span className="font-medium text-foreground">off by default</span>.
          Enable only the capabilities that are actually available in this
          deployment. Your selection is saved automatically and applies to all
          chats.
        </p>
      </div>

      {/* Tool list */}
      <div className="flex flex-col gap-2">
        {catalog.map((meta) => {
          const id = meta.id
          const enabled = enabledTools.includes(id)
          const saving = savingTool === id
          const saved = lastSaved === id
          const unavailable = !meta.available

          return (
            <button
              key={id}
              onClick={() => toggleTool(id)}
              disabled={savingTool !== null || unavailable}
              className={cn(
                "flex items-center gap-3 rounded-xl border px-4 py-3 text-left transition-all",
                enabled
                  ? "border-primary/40 bg-primary/8 shadow-sm"
                  : "border-border bg-background hover:bg-muted/30",
                savingTool !== null && savingTool !== id && "opacity-60",
                unavailable && "cursor-not-allowed opacity-55"
              )}
            >
              <span className="text-xl leading-none">{meta.icon}</span>
              <div className="min-w-0 flex-1">
                <p
                  className={cn(
                    "text-xs font-semibold",
                    enabled ? "text-primary" : "text-foreground"
                  )}
                >
                  {meta.label}
                </p>
                <p className="mt-0.5 text-[11px] leading-snug text-muted-foreground">
                  {meta.description}
                </p>
                {meta.note && (
                  <p className="mt-1 text-[10px] leading-snug text-muted-foreground/80">
                    {meta.note}
                  </p>
                )}
              </div>

              {/* Status pill */}
              <div
                className={cn(
                  "flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-semibold transition-all",
                  unavailable
                    ? "bg-muted text-muted-foreground"
                    : saved
                    ? "bg-green-500/10 text-green-600 dark:text-green-400"
                    : enabled
                      ? "bg-primary/15 text-primary"
                      : "bg-muted text-muted-foreground"
                )}
              >
                {unavailable ? null : saving ? (
                  <Loader2 className="size-3 animate-spin" />
                ) : saved ? (
                  <Check className="size-3" />
                ) : (
                  <span
                    className={cn(
                      "size-1.5 rounded-full",
                      enabled ? "bg-primary" : "bg-muted-foreground/40"
                    )}
                  />
                )}
                {unavailable
                  ? meta.availabilityLabel
                  : saving
                    ? "Saving…"
                    : saved
                      ? "Saved"
                      : enabled
                        ? "On"
                        : "Off"}
              </div>
            </button>
          )
        })}
      </div>

        <section className="rounded-xl border border-border bg-muted/30 p-4">
          <div className="mb-2 flex items-center justify-between">
            <p className="text-xs font-semibold text-foreground">Email login</p>
            <span className="text-[10px] text-muted-foreground">Per-user SMTP auth</span>
          </div>
          <p className="mb-3 text-[11px] leading-relaxed text-muted-foreground">
            The app uses its configured SMTP server. You only provide your email username
            and password here.
          </p>
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="text-[10px] text-muted-foreground">
              Username
              <input
                value={smtpForm.user}
                onChange={(e) => setSmtpForm((prev) => ({ ...prev, user: e.target.value }))}
                className="mt-1 block w-full rounded-lg border border-border px-2 py-1 text-sm"
              />
            </label>
            <label className="text-[10px] text-muted-foreground">
              Password
              <input
                type="password"
                value={smtpForm.pass}
                onChange={(e) => setSmtpForm((prev) => ({ ...prev, pass: e.target.value }))}
                className="mt-1 block w-full rounded-lg border border-border px-2 py-1 text-sm"
              />
            </label>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <button
              onClick={async () => {
                setSmtpSaving(true)
                try {
                  await save({
                    smtpUser: smtpForm.user,
                    smtpPass: smtpForm.pass,
                  })
                  setSmtpMessage("Saved")
                } catch {
                  setSmtpMessage("Failed to save email credentials")
                } finally {
                  setSmtpSaving(false)
                  setTimeout(() => setSmtpMessage(""), 3000)
                }
              }}
              disabled={smtpSaving}
              className="rounded-lg bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50"
            >
              {smtpSaving ? "Saving..." : "Save credentials"}
            </button>
            {smtpMessage && (
              <span className="text-[11px] text-muted-foreground">{smtpMessage}</span>
            )}
          </div>
          {!smtpConfigured && (
            <p className="mt-2 text-[11px] text-destructive">
              Email tool stays disabled until username and password are saved.
            </p>
          )}
        </section>

        {error && (
          <p className="text-center text-[11px] text-destructive">
            {error}
          </p>
        )}

        {enabledCount === 0 && (
          <p className="text-center text-[11px] text-muted-foreground/50">
            No tools active — Aurelius will answer from its own knowledge only.
          </p>
        )}
      </div>
    </div>
  )
}
