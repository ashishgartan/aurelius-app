import nodemailer from "nodemailer"

export interface SmtpConfig {
  user:    string
  pass:    string
}

export async function sendSmtpEmail(
  config: SmtpConfig,
  options: { to: string; subject: string; text: string }
) {
  const host = process.env.SMTP_HOST
  const port = Number(process.env.SMTP_PORT ?? "587")
  const secure = process.env.SMTP_SECURE === "true" || port === 465
  const from = process.env.SMTP_FROM ?? config.user

  if (!host || !config.user || !config.pass) {
    throw new Error("SMTP configuration missing app host or user credentials")
  }

  const transporter = nodemailer.createTransport({
    host,
    port,
    secure,
    auth: { user: config.user, pass: config.pass },
  })

  await transporter.sendMail({
    from,
    to: options.to,
    subject: options.subject,
    text: options.text,
  })
}
