import type { UserSettings } from "../../types/auth.ts"

interface SettingsResponse {
  settings?: UserSettings
  error?: string
}

export async function saveSettingsRequest(
  fetchImpl: typeof fetch,
  current: UserSettings,
  patch: Partial<UserSettings>
): Promise<UserSettings> {
  const merged = { ...current, ...patch }

  const res = await fetchImpl("/api/settings", {
    method: "PUT",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(merged),
  })

  if (!res.ok) {
    const body = await res.json().catch(() => ({} as SettingsResponse))
    throw new Error(body.error ?? `Save failed (${res.status})`)
  }

  const data = (await res.json()) as SettingsResponse
  return data.settings ?? merged
}
