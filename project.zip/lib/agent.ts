// lib/agent.ts

import { buildAgentRegistry } from "@/lib/agents/index"
import { routeQuery }         from "@/lib/agents/router"
import { executeAgent }       from "@/lib/agents/executor"
import type { Provider }      from "@/types/chat"
import type { RegistryOptions } from "@/lib/agents/index"

export type AgentChunk =
  | { type: "tool_start";     tool: string; input: string }
  | { type: "tool_end";       tool: string; output: string }
  | { type: "token";          content: string }
  | { type: "thinking_token"; content: string }
  | { type: "artifact";       artifactId: string; filename: string; lang: string; sizeBytes: number }
  | { type: "usage";          inputTokens: number; outputTokens: number; toolsUsed: string[] }
  | { type: "error";          message: string }
  | { type: "title";          title: string }

interface AgentStreamOptions {
  message:       string
  history:       { role: string; content: string }[]
  provider:      Provider
  instructions?: string
  language?:     string
  length?:       "concise" | "balanced" | "detailed"
  tone?:         "professional" | "casual" | "technical"
  ragContext?:   string
  sessionId?:    string
  userId?:       string
  enabledTools?: string[]   // ← new
}

const LENGTH_INSTRUCTIONS = {
  concise:  "Keep responses short and to the point. Avoid unnecessary explanation.",
  balanced: "Balance brevity with completeness. Use detail only where it adds value.",
  detailed: "Be thorough and comprehensive. Explain reasoning, show examples.",
}

const TONE_INSTRUCTIONS = {
  professional: "Use a clear, professional tone.",
  casual:       "Use a friendly, conversational tone.",
  technical:    "Use precise technical language. Assume expertise.",
}

const AGENT_CONTEXT: Record<string, string> = {
  math_agent:         "You are in math mode. Always use the calculator tool for numerical computations — never calculate in your head.",
  research_agent:     "You are in research mode. Always use the web search tool for current information. " +
    "When writing your response, cite sources inline using numbered superscripts like [1], [2] — " +
    "place the citation immediately after the sentence or fact it supports. " +
    "Then end your response with a '## Sources' section listing every cited source as a clickable link:\n" +
    "## Sources\n1. [Title](url)\n2. [Title](url)\n" +
    "Example of correct inline citation: 'Bitcoin rose 4% on Monday [1], driven by ETF inflows [2].'\n" +
    "Never omit the Sources section — it is mandatory whenever you used the search tool. " +
    "If search returns no results or fails, answer from memory and note it may not be current.",
  code_agent:         "You are in code mode. Provide precise, working code. Explain logic only when asked.",
  knowledge_agent:    "You are in document mode. Always search the user's uploaded documents before answering. Cite the source file for every claim.",
  productivity_agent: "You are in productivity mode. Use the send_email tool when the user wants to send a message. Ensure you have a recipient, subject, and body before calling the tool. Do not imply task or calendar integrations exist when they are not available.",
}

function buildSystemPrompt(opts: AgentStreamOptions, agentName: string): string {
  const parts: string[] = []

  parts.push(`You are Aurelius, a helpful AI assistant with real tool capabilities. You can actually perform actions — not just describe them.`)

  const agentContext = AGENT_CONTEXT[agentName]
  if (agentContext) parts.push(agentContext)

  parts.push(`## Formatting rules
- Always use Markdown. Your responses are rendered in a Markdown-aware UI.
- Use ## or ### headings to introduce major sections.
- Use **bold** for key terms and important concepts.
- Use bullet lists (- item) or numbered lists for enumerations — never write them inline as "1. ... 2. ...".
- Use backtick code blocks with a language tag for all code (e.g. \`\`\`javascript).
- Use tables for comparisons when there are 2+ attributes across 2+ items.
- Leave a blank line between sections for readability.
- Never write walls of text — break information into scannable sections.
- Keep the opening sentence short and direct. State what the thing is before going into detail.`)

  parts.push(`## Handling short or vague messages
- If the user sends a single word or short phrase (e.g. "mongodb", "python", "cars"), treat it as "tell me about [topic]" and give a well-structured overview.
- Never return an empty response. If the message is ambiguous, make a reasonable assumption and answer, then offer to go deeper.
- If a question is genuinely unclear, give a brief best-guess answer first, then ask for clarification.`)

  if (agentName !== "general_agent") {
    parts.push(`## Tool usage\nUse your available tools proactively when they will improve the answer. Report tool results concisely inline.`)
  }

  const length = opts.length ?? "balanced"
  const tone   = opts.tone   ?? "professional"
  parts.push(LENGTH_INSTRUCTIONS[length])
  parts.push(TONE_INSTRUCTIONS[tone])

  if (opts.language && opts.language !== "English") {
    parts.push(`Always respond in ${opts.language}, regardless of the language the user writes in.`)
  }

  if (opts.ragContext?.trim()) parts.push(opts.ragContext.trim())
  if (opts.instructions?.trim()) parts.push("Additional instructions from the user:\n" + opts.instructions.trim())

  return parts.join("\n\n")
}

export async function createAgentStream(
  options: AgentStreamOptions
): Promise<AsyncGenerator<AgentChunk>> {
  const { message, history, provider, sessionId, userId, enabledTools } = options

  const AGENT_REGISTRY = buildAgentRegistry({ sessionId, userId, enabledTools } as RegistryOptions)

  if (AGENT_REGISTRY.length === 0) {
    throw new Error("No agents available. Check your environment variables (GROQ_API_KEY, TAVILY_API_KEY, etc.)")
  }

  const chosenName = await routeQuery(message, AGENT_REGISTRY, provider)

  const agent =
    AGENT_REGISTRY.find((a) => a.name === chosenName) ??
    AGENT_REGISTRY.find((a) => a.name === "general_agent") ??
    AGENT_REGISTRY[0]

  console.log(`[router] "${message.slice(0, 60)}" → ${agent.name} (Active tools: ${AGENT_REGISTRY.length - 1})`)

  const systemText = buildSystemPrompt(options, agent.name)
  return executeAgent(agent, message, history, systemText, provider)
}
