// proxy.ts
import { NextResponse, type NextRequest } from "next/server"
import { verifyToken, COOKIE_NAME } from "@/lib/jwt"

const PROTECTED = ["/chat", "/dashboard", "/settings", "/profile", "/options", "/tools"]
const AUTH_ONLY = ["/login", "/signup"]

export async function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl
  const isProtected = PROTECTED.some((p) => pathname.startsWith(p))
  const isAuthOnly = AUTH_ONLY.some((p) => pathname.startsWith(p))

  const token = req.cookies.get(COOKIE_NAME)?.value ?? null
  const user = token ? await verifyToken(token) : null

  if (isProtected && !user) {
    const url = req.nextUrl.clone()
    url.pathname = "/login"
    url.searchParams.set("from", pathname)
    return NextResponse.redirect(url)
  }

  if (isAuthOnly && user) {
    const raw = req.nextUrl.searchParams.get("from") ?? "/chat"
    const from = raw.startsWith("/") && !raw.startsWith("//") ? raw : "/chat"
    const url = req.nextUrl.clone()
    url.pathname = from
    url.search = ""
    return NextResponse.redirect(url)
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    "/login",
    "/signup",
    "/chat/:path*",
    "/dashboard/:path*",
    "/settings/:path*",
    "/profile/:path*",
    "/options/:path*",
    "/tools/:path*",
  ],
}
